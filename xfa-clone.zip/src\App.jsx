import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import OriginalHeader from './components/OriginalHeader'
import OriginalMain from './components/OriginalMain'
import OriginalFooter from './components/OriginalFooter'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import CookieBanner from './components/CookieBanner'
import Services from './pages/Services'
import AboutUs from './pages/AboutUs'

function App() {
  return (
    <BrowserRouter>
      <div className="app-shell">
        <Routes>
          {/* Carbon copy of the exact XFA homepage */}
          <Route path="/" element={
            <>
              <OriginalHeader />
              <OriginalMain />
              <OriginalFooter />
            </>
          } />

          {/* Standard React app routes for other pages */}
          <Route path="/*" element={
            <>
              <Navbar />
              <Routes>
                <Route path="/services"  element={<Services />} />
                <Route path="/services/*" element={<Services />} />
                <Route path="/about"     element={<AboutUs />} />
                <Route path="/about/*"   element={<AboutUs />} />
                <Route path="/contact"   element={<ContactPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
              <Footer />
              <CookieBanner />
            </>
          } />
        </Routes>
      </div>
    </BrowserRouter>
  )
}

/* Minimal inline contact page */
function ContactPage() {
  return (
    <main style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '1rem', padding: '4rem 2rem', textAlign: 'center' }}>
      <span style={{ background: '#f4f6f9', color: '#1a5ea8', fontSize: '0.72rem', fontWeight: 700, letterSpacing: '1.5px', textTransform: 'uppercase', padding: '0.25rem 0.7rem', borderRadius: '30px', border: '1px solid #c8daf2' }}>Contact</span>
      <h1 style={{ fontSize: '2rem', color: '#0a1628', maxWidth: 600 }}>Contact the XFA Team</h1>
      <p style={{ color: '#6b7280', maxWidth: 480, lineHeight: 1.7 }}>
        Reach out to our senior leadership team directly. We are committed to responding to all enquiries promptly.
      </p>
      <a href="mailto:info@x-fa.com" style={{ display: 'inline-block', background: '#1a5ea8', color: '#fff', padding: '0.75rem 1.8rem', borderRadius: 5, fontWeight: 600, fontSize: '0.9rem', marginTop: '0.5rem' }}>
        Email info@x-fa.com
      </a>
      <p style={{ color: '#6b7280', fontSize: '0.8rem' }}>XFA is a division of <a href="https://www.marex.com/" target="_blank" rel="noreferrer" style={{ color: '#1a5ea8' }}>Marex</a></p>
    </main>
  )
}

// Clear out global css for carbon copy mode on home page by dynamically managing styles, or just let them cascade. 
// Since they want a pixel-perfect carbon copy, OriginalMain brings it exactly.
export default App
